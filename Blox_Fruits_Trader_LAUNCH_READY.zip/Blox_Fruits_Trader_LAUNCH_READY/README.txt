BLOX FRUITS TRADER — LAUNCH READY

1) Upload index.html to the ROOT of your GitHub Pages repository.
2) In Firebase, enable Anonymous Authentication.
3) Create Realtime Database.
4) Put your Firebase Web App config into SITE_FIREBASE_CONFIG near the top of index.html ONCE before publishing.
5) Put firebase_rules.json into Firebase Realtime Database > Rules and publish it.
6) GitHub Pages should use main branch / (root).

IMPORTANT:
- Visitors do NOT need to paste Firebase config.
- Never put a Firebase service-account private key or password in the website.
- Firebase Web App config values are client-side configuration values; database security is controlled by Rules.
- New trades are stored with ownerUid so a user can modify only their own trade under the included rules.
- Existing trades created by older versions may not be editable because they do not have ownerUid.

ONE-TIME SITE OWNER CONFIG:
Open index.html and find:
const SITE_FIREBASE_CONFIG={...};
Replace only the placeholder values with the 7 values from Firebase Project Settings > Your apps > Web app.
